let esqueleto = "off";
let esqueletoStop = document.getElementById("esqueletooff");
let botonSonido = new Audio("/sounds/botonbailar.mp3");
let botonAudio = new Audio("/sounds/sisa.mp3");
let p = document.getElementById("parrafo")

function bailar()
{
    if (esqueleto == "off")
    {

        p.innerHTML = `<i class="fa-solid fa-pause"></i>`
        esqueleto = "on"
        esqueletoStop.classList.add("on");
        console.log("on");
        esqueletoStop.addEventListener('click', () =>
        {
            botonSonido.play();
        })
        esqueletoStop.addEventListener('click', () =>
        {
            botonAudio.play();
        })

    } else
    {
        esqueleto = "off";
        esqueletoStop.classList.remove("on");
        esqueletoStop.addEventListener('click', () =>
        {
            botonAudio.pause();
        })
        p.innerHTML = `<i class="fa-solid fa-play"></i>`
    }
}